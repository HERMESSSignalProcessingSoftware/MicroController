/*******************************************************************************
 * (c) Copyright 2009-2015 Microsemi SoC Products Group.  All rights reserved.
 * 
 * SmartFusion2 microcontroller subsystem timer example demonstrating the use of
 * background load of a 32 bit timer.
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 7352 $
 * SVN $Date: 2015-04-23 13:52:10 +0530 (Thu, 23 Apr 2015) $
 */
#include "drivers/mss_timer/mss_timer.h"
#include "drivers/mss_gpio/mss_gpio.h"

/*
 * Sequence of delays used to flash the LED
 */
#define SEQUENCE_LENGTH     11

static const uint32_t g_delays_list[SEQUENCE_LENGTH] =
{
    0x02000000,
    0x01000000,
    0x00800000,
    0x00400000,
    0x00200000,
    0x00100000,
    0x00200000,
    0x00400000,
    0x00800000,
    0x01000000,
    0x02000000
};

/*
 * LEDs masks used to switch on/off LED through GPIOs.
 */
#define LED_MASK   (uint32_t)0x0000000Fu

/*
 * LED pattern
 */
volatile uint32_t g_gpio_pattern = LED_MASK;

/*==============================================================================
 * main function.
 */
int main()
{
    /*--------------------------------------------------------------------------
     * Configure GPIOs
     */
    MSS_GPIO_init();

    MSS_GPIO_config(MSS_GPIO_0, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_1, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_2, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_3, MSS_GPIO_OUTPUT_MODE);
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /*--------------------------------------------------------------------------
     * Configure Timer1
     */
    MSS_TIM1_init(MSS_TIMER_PERIODIC_MODE);
    MSS_TIM1_load_immediate(g_delays_list[0]);
    MSS_TIM1_start();
    MSS_TIM1_enable_irq();
    
    for(;;)
    {
        ;
    }
}

/*==============================================================================
 * Toggle LEDs on TIM1 interrupt and update delay for after next interrupt.
 */
void Timer1_IRQHandler(void)
{
    static uint32_t delay_idx = 0;
    
    /* Toggle LEDs on/off */
    if(g_gpio_pattern & LED_MASK)
    {
        g_gpio_pattern &= ~LED_MASK;
    }
    else
    {
        g_gpio_pattern |= LED_MASK;
    }
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /* Move to next delay in sequence. */
    ++delay_idx;
    if(delay_idx >= SEQUENCE_LENGTH)
    {
        delay_idx = 0;
    }
    MSS_TIM1_load_background(g_delays_list[delay_idx]);
    
    /* Clear TIM1 interrupt */
    MSS_TIM1_clear_irq();
}
