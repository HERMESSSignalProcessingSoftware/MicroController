/*******************************************************************************
 * (c) Copyright 2009-2015 Microsemi SoC Products Group.  All rights reserved.
 * 
 * SmartFusion2 microcontroller subsystem timer example demonstrating the use of
 * a 32 bit timer in one-shot mode.
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 7901 $
 * SVN $Date: 2015-09-30 15:42:42 +0530 (Wed, 30 Sep 2015) $
 */
#include "drivers/mss_timer/mss_timer.h"
#include "drivers/mss_gpio/mss_gpio.h"
#include "CMSIS/system_m2sxxx.h"

/*
 * LEDs masks used to switch on/off LED through GPIOs.
 */
#define LED_MASK   (uint32_t)0x0000000F

/*
 * Push buttons mask used to detect that a button connected to the GPIO is being
 * pushed.
 */
#define SW1_MASK    (uint32_t)0x00000100

/*
 * LEDs pattern
 */
volatile uint32_t g_gpio_pattern = LED_MASK;

/*==============================================================================
 * main function.
 */
int main()
{
    uint32_t gpio_in;
    uint32_t timer2_load_value;
    
    /*--------------------------------------------------------------------------
     * Ensure the CMSIS-HAL provided g_FrequencyPCLK0 global variable contains
     * the correct frequency of the APB bus connecting the MSS timer to the
     * rest of the system.
     */
    SystemCoreClockUpdate();

    /*--------------------------------------------------------------------------
     * Configure GPIOs
     */
    MSS_GPIO_init();
    
    /* LEDs connected to MSS GPIO 0 to 3. */
    MSS_GPIO_config(MSS_GPIO_0, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_1, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_2, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_3, MSS_GPIO_OUTPUT_MODE);
    
    /* SW1 connected to MSS GPIO 8.*/
    MSS_GPIO_config(MSS_GPIO_8 , MSS_GPIO_INPUT_MODE);
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /*--------------------------------------------------------------------------
     * Configure Timer 2
     */
    MSS_TIM2_init(MSS_TIMER_ONE_SHOT_MODE);
    timer2_load_value = g_FrequencyPCLK0 * 4;
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /*--------------------------------------------------------------------------
     * Foreground loop.
     */
    for(;;)
    {
        gpio_in = MSS_GPIO_get_inputs();
        
        /* Switch on LEDs for 4 seconds if SW1 is pressed */
        if(0 == (gpio_in & SW1_MASK))
        {
            /* Switch on LEDs */
            g_gpio_pattern &= ~LED_MASK;
            MSS_GPIO_set_outputs(g_gpio_pattern);
            
            /* set timer 2 for one-shot interrupt. */
            MSS_TIM2_load_immediate(timer2_load_value);
            MSS_TIM2_start();
            MSS_TIM2_enable_irq();
    
            /* Wait for timer 2 interrupt to clear LEDs. */
            while(0 == (g_gpio_pattern & LED_MASK));
            {
                ;
            }
        }
    }
}

/*==============================================================================
 * Toggle LEDs on TIM2 interrupt.
 */
void Timer2_IRQHandler(void)
{
    /* Toggle LEDs on/off */
    if(g_gpio_pattern & LED_MASK)
    {
        g_gpio_pattern &= ~LED_MASK;
    }
    else
    {
        g_gpio_pattern |= LED_MASK;
    }
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /* Clear TIM2 interrupt */
    MSS_TIM2_clear_irq();
}
