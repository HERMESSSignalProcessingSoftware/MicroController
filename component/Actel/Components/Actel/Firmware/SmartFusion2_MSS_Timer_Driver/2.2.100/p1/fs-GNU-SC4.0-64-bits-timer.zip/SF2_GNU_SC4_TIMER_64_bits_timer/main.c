/*******************************************************************************
 * (c) Copyright 2009-2015 Microsemi SoC Products Group.  All rights reserved.
 * 
 * SmartFusion2 microcontroller subsystem timer 64 bits timer example.
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 7901 $
 * SVN $Date: 2015-09-30 15:42:42 +0530 (Wed, 30 Sep 2015) $
 */
#include "drivers/mss_timer/mss_timer.h"
#include "drivers/mss_gpio/mss_gpio.h"
#include "CMSIS/system_m2sxxx.h"

/*
 * LEDs masks used to switch on/off LED through GPIOs.
 */
#define LEDS_MASK   (uint32_t)0x0000000Fu

/*
 * Push buttons mask used to detect that a button connected to the GPIO is being
 * pushed.
 */
#define SW1_MASK    (uint32_t)0x00000100u

/*
 * LEDs pattern
 */
volatile uint32_t g_gpio_pattern = LEDS_MASK;

int main()
{
    uint32_t gpio_in;
    uint32_t tim64_load_value;
    
    /*--------------------------------------------------------------------------
     * Ensure the CMSIS-HAL provided g_FrequencyPCLK0 global variable contains
     * the correct frequency of the APB bus connecting the MSS timer to the MSS.
     */
    SystemCoreClockUpdate();
    
    /*--------------------------------------------------------------------------
     * Configure GPIOs
     */
    MSS_GPIO_init();
    
    /* LEDs connected to MSS GPIO 0 to 3. */
    MSS_GPIO_config(MSS_GPIO_0, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_1, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_2, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MSS_GPIO_3, MSS_GPIO_OUTPUT_MODE);
    
    /* SW1 connected to MSS GPIO 8.*/
    MSS_GPIO_config(MSS_GPIO_8 , MSS_GPIO_INPUT_MODE);
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /*--------------------------------------------------------------------------
     * Configure Timer64
     */
    MSS_TIM64_init(MSS_TIMER_PERIODIC_MODE);
    /* 
     * Use the timer input frequency as load value to achieve a one second
     * periodic interrupt.
     */
    tim64_load_value = g_FrequencyPCLK0;
    MSS_TIM64_load_immediate(0, tim64_load_value);
    MSS_TIM64_start();
    MSS_TIM64_enable_irq();

    /*--------------------------------------------------------------------------
     * Foreground loop.
     */
    for(;;)
    {
        gpio_in = MSS_GPIO_get_inputs();

        /* Pause TIM1 while SW1 is pressed */
        if(0 == (gpio_in & SW1_MASK))
        {
            MSS_TIM64_stop();
            
            /* Wait for SW1 to be released */
            do {
                gpio_in = MSS_GPIO_get_inputs();
            } while(0 == (gpio_in & SW1_MASK));
            
            MSS_TIM64_start();
        }
    }
}

/*==============================================================================
 * Toggle LEDs on TIM64 interrupt.
 */
void Timer1_IRQHandler(void)
{
    /* Toggle LEDs on/off */
    if(g_gpio_pattern & LEDS_MASK)
    {
        g_gpio_pattern &= ~LEDS_MASK;
    }
    else
    {
        g_gpio_pattern |= LEDS_MASK;
    }
    
    MSS_GPIO_set_outputs(g_gpio_pattern);
    
    /* Clear interrupt */
    MSS_TIM64_clear_irq();
}
