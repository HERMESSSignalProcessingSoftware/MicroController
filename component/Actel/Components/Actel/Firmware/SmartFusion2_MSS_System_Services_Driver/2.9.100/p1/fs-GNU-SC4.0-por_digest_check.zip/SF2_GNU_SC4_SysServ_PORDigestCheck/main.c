/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * POR Digest error Testing.
 *
 * Please refer to file README.TXT for further details about this example.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */

#include "drivers/mss_uart/mss_uart.h"
#include "mss_comblk.h"
#include "drivers/mss_sys_services/mss_sys_services.h"

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
******************* SmartFusion2 POR Digest Check ********************\r\n\
**********************************************************************\r\n";

/*==============================================================================
  Private functions.
 */
static void display_greeting(void);
static void sys_services_event_handler(uint8_t opcode, uint8_t response);
static void sys_services_data_event_handler(uint8_t error_type);
static void init_uart(void);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  hex2ASCII() function convert Hex value to ASCII value.
 */
void hex2ASCII(uint8_t* buf, uint8_t input)
{
    if((0x0 <= (input & 0x0f)) && ((input & 0x0f) <= 0x9))
    {
        buf[1] = ((input & 0x0f) + '0');
    }
    else if((0xa <= (input & 0x0f)) && ((input & 0x0f) <= 0xf))
    {
        buf[1] = ((input & 0x0f) + 'a' - 0x0a);
    }
    
    if((0x0 <= (input >> 4)) && ((input >> 4) <= 0x9))
    {
        buf[0] = ((input >> 4) + '0');
    }
    else if((0xa <= (input >> 4)) && ((input >> 4) <= 0xf))
    {
        buf[0] = ((input >> 4) + 'a' - 0x0a);
    }
    
}

/*==============================================================================
  Main function.
 */
int main(void)
{
    /*
     * Initialize UART.
     */
   init_uart();
    
    /*
     * Display greeting message.
     */
    display_greeting();
    
    /*
     * Initialize peripherals.
     */
    MSS_SYS_init(sys_services_event_handler);

    /*
     * Foreground loop.
     */
    while(1);
}

/*==============================================================================
  System Services event handler.
 */
static void sys_services_event_handler(uint8_t opcode, uint8_t response)
{
    if(POR_DIGEST_ERROR_OPCODE == opcode)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                              (const uint8_t*)"\n\r POR Digest Check Command and Error Byte Received.");
        sys_services_data_event_handler(response);
    }
}

/*==============================================================================
  System Services Data event handler.
 */
static void sys_services_data_event_handler(uint8_t error_type)
{
    uint8_t fabric_digest_check_failure;
    uint8_t envm0_digest_check_failure;
    uint8_t envm1_digest_check_failure;
    static uint8_t buffer[2];

    fabric_digest_check_failure = error_type & MSS_SYS_DIGEST_CHECK_FABRIC;
    envm0_digest_check_failure = error_type & MSS_SYS_DIGEST_CHECK_ENVM0;
    envm1_digest_check_failure = error_type & MSS_SYS_DIGEST_CHECK_ENVM1;

    MSS_UART_polled_tx_string(gp_my_uart,
                              (const uint8_t*)"\n\r POR Digest Error Type:");
    hex2ASCII(buffer, error_type);
    MSS_UART_polled_tx(gp_my_uart, buffer, 2);

    if(fabric_digest_check_failure)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n  Fabric POR digest check failed.\n\r");
    }
    if(envm0_digest_check_failure)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n  eNVM0 POR digest check failed.");
    }
    if(envm1_digest_check_failure)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n  eNVM1 POR digest check failed.");
    }
}

/*==============================================================================
  Initialize the UART.
 */
static void init_uart(void)
{
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
}

