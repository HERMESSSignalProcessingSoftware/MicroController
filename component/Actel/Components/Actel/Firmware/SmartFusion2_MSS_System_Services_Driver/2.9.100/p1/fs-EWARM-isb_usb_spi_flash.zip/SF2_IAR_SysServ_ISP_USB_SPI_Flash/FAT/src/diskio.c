/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2007        */
/*-----------------------------------------------------------------------*/
/* This is a stub disk I/O module that acts as front end of the existing */
/* disk I/O modules and attach it to FatFs module with common interface. */
/*-----------------------------------------------------------------------*/

#include "at25df641.h"
#include "diskio.h"

/*-----------------------------------------------------------------------*/
/* Correspondence between physical drive number and physical drive.      */
/*-----------------------------------------------------------------------*/

#define ATA		2
#define MMC		1
#define USB		0



/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber (0..) */
)
{
    //DSTATUS stat;

    switch (pdrv) 
    {
        case ATA :
            //result = ATA_disk_initialize();
            // translate the reslut code here
            //return stat;

        case MMC :
            //result = MMC_disk_initialize();
            // translate the reslut code here
            //return stat;
          return 0;

        case USB :
            FLASH_init();
            FLASH_global_unprotect();
            return 0;
    }
    return STA_NOINIT;

}

/*-----------------------------------------------------------------------*/
/* Return Disk Status                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE drv		/* Physical drive nmuber (0..) */
)
{
	return 0;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address (LBA) */
	BYTE count		/* Number of sectors to read (1..255) */
)
{
    //DRESULT res;

    switch (pdrv) 
    {
        case ATA :
            // translate the arguments here
            //result = ATA_disk_read(buff, sector, count);
            //return res;

        case MMC :
            // translate the arguments here
            //result = MMC_disk_read(buff, sector, count);
            // translate the reslut code here
            //return res;
            return(RES_OK);

        case USB :
            // translate the arguments here
            FLASH_read(sector*512, buff, count*512);
            return(RES_OK);
    }
    return RES_PARERR;
	
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

#if _USE_WRITE
    uint8_t temp_buf[4096];

DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber (0..) */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address (LBA) */
	BYTE count			/* Number of sectors to write (1..255) */
)
{
    int block_num;
    int block_sect_num;
    int loop_count;
    
    block_num = sector/8;
    block_sect_num = sector%8;
    
    FLASH_read(block_num*4096, temp_buf, sizeof(temp_buf));
    for(loop_count =0; loop_count < 512; loop_count++)
    {
        temp_buf[(block_sect_num*512) + loop_count] = buff[loop_count];
    }

    FLASH_erase_4k_block(block_num*4096);
    FLASH_program(block_num*4096, (uint8_t *) temp_buf, 4096);
    return (RES_OK);

 
}
#endif /* _READONLY */



/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/
uint32_t sect_size1;
uint32_t sect_size2;

#if _USE_IOCTL
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	UINT *result = (UINT *)buff;
	switch (cmd) {
    case CTRL_SYNC:
    	break;
    case CTRL_POWER:
    	break;
    case CTRL_LOCK:
    	break;
    case CTRL_EJECT:
    	break;
    case GET_SECTOR_COUNT:
    	*result = 0x1FFF; //0x1FFF;
    	break;
    case GET_SECTOR_SIZE:
    	*result = 512;
        sect_size1 = *result;
        //sect_size2 = (uint32_t *)(*buff);
    	break;
    case GET_BLOCK_SIZE:
    	*result = 8;/*in no.of Sectors */
    	break;
    default:
    	break;
    }
	return(RES_OK);

}
#endif
