/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * This Example Project demonstrates the usage of MSS Tamper Control Service 
 * APIs for detecting tamper events and to control power ON/OFF after key fetch.
 *
 * To know more about this example project, please refer README.TXT in this 
 * project's folder.
 * 
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include <stdio.h>
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_sys_services/mss_comblk.h"

/*==============================================================================
  Macro
 */
#define TAMPER_CATEGORY_BUFFER_ACCESS                   0x01u
#define TAMPER_CATEGORY_DEBUG                           0x02u
#define TAMPER_CATEGORY_CHECK_DIGEST                    0x03u
#define TAMPER_CATEGORY_ECC_SETUP_INSTRUCTION           0x04u
#define TAMPER_CATEGORY_FACTORY_PRIVATE                 0x05u
#define TAMPER_CATEGORY_KEY_VALIDATION                  0x06u
#define TAMPER_CATEGORY_MISC                            0x07u
#define TAMPER_CATEGORY_PASSCODE_MATCH                  0x08u
#define TAMPER_CATEGORY_PASSCODE_SETUP_INSTRUCTION      0x09u
#define TAMPER_CATEGORY_PROGRAMMING                     0x0au
#define TAMPER_CATEGORY_PUBLIC_INFORMATION              0x0bu
#define TAMPER_CATEGORY_PUF_KEY_MANAGEMENT              0x0cu
#define TAMPER_CATEGORY_UNUSED                          0x0du
#define TAMPER_CATEGORY_ZEROIZATION_RECOVERY            0x0fu
   
/*==============================================================================
 * UART selection.
 * Replace the line below with this one if you want to use UART1 instead of
 * UART0:
 * mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
 * Global Variables.
 */

const uint8_t g_separator[] =
"\r\n----------------------------------------------------------------------";

/*==============================================================================
 * Private function declaration.
 */
static void display_message
(
    const uint8_t* p_msg,
    uint16_t msg_size
);
static void sys_services_event_handler(uint8_t opcode, uint8_t response);

/*==============================================================================
  Initialize the UART.
 */
static void init_uart(void)
{
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | \
                  MSS_UART_NO_PARITY |   \
                  MSS_UART_ONE_STOP_BIT);
}

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t title[] =    
"\r\n\
\r\n********************************************************************** \
\r\n************** Tamper Control Service Example Project **************** \
\r\n********************************************************************** \
\r\n This example project exercises Tamper control services \
\r\n  - Press \"1\" to start clock monitoring service. \
\r\n  - Press \"2\" to stop clock monitoring service. \
\r\n  - Press \"3\" to enable PUF Power down. \
\r\n  - Press \"4\" to disable PUF Power down. \
\r\n  - Press \"5\" to clear lock parity. \
\r\n  - Press \"6\" to clear mesh short perform point addition. \
\r\n----------------------------------------------------------------------";

/*==============================================================================
  Main function.
 */
int main(void)
{
    uint8_t status = 0u;
    uint8_t rx_char;
    uint8_t rx_size = 1u;
  
    /*
     * Initialize UART.
     */
    init_uart();
    
    /*
     * Display greeting message.
     */
    display_message(title, sizeof(title));
     
    /* 
     * System Services Driver Initialization.
     */
    MSS_SYS_init(sys_services_event_handler);

    do
    {       
        rx_size = MSS_UART_get_rx(gp_my_uart, &rx_char, sizeof(rx_char));
        if(rx_size > 0u)
        {
            rx_size = 0u;
            switch(rx_char)
            {
                case '1':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected start clock monitoring service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_start_clock_monitor();
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service start clock monitoring successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service start clock monitoring failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case '2':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected stop clock monitoring service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_stop_clock_monitor();
                        
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service stop clock monitoring successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service stop clock monitoring failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;

                case '3':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected enable PUF power down service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_enable_puf_power_down();
                        
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service enable PUF power down successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service enable PUF power down failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case '4':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected disable PUF power down service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_disable_puf_power_down();
                        
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service disable PUF power down successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service disable PUF power down failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case '5':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected clear lock parity service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_clear_lock_parity();
                        
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service clear lock parity successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service clear lock parity failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case '6':
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected clear mesh short service.");
                        /* Send command to G4M controller */
                        status = MSS_SYS_clear_mesh_short();
                        
                        /* Display the status in terminal window */
                        if(MSS_SYS_SUCCESS == status)
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service clear mesh short successful.");
                        }
                        else
                        {
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Service clear mesh short failed.");
                        }
                        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                default:
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Error: Invalid action.");
                        display_message(title, sizeof(title));
                    break;
            }
        }
    }while(1);
}

/*==============================================================================
  System Services event handler.
 */
static void sys_services_event_handler(uint8_t opcode, uint8_t response)
{
    if((opcode >= TAMPER_ATTEMPT_BOUNDARY_SCAN_OPCODE) && \
      (opcode <= TAMPER_ATTEMPT_ZEROIZATION_RECOVERY_OPCODE))
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\n\r Tamper attempt event detected.");
    }
    else if((opcode >= TAMPER_FAILURE_BOUNDARY_SCAN_OPCODE) && \
           (opcode <= TAMPER_FAILURE_ZEROIZATION_RECOVERY_OPCODE))
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\n\r Tamper failure event detected.");
    }
    else if(opcode == TAMPER_CLOCK_ERROR_DETECT_OPCODE)
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\n\r Tamper clock monitor error detected.");
    }
    else if((opcode >= TAMPER_HARDWARE_MONITOR_JTAGACTIVE_ERROR_OPCODE) && \
            (opcode <= TAMPER_HARDWARE_MONITOR_MESHSHORT_ERROR_OPCODE))
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\n\r Hardware monitor error detected.");
    }
    else
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\n\r Invalid event detected.");
    }
}

/******************************************************************************
* Display Message
******************************************************************************/
static void display_message
(
    const uint8_t* p_msg, 
    uint16_t msg_size 
)
{
    MSS_UART_polled_tx(gp_my_uart, p_msg, msg_size);
}
