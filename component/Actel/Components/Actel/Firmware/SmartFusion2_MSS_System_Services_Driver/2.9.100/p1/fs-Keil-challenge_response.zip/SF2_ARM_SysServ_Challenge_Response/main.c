/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * This Example Project demonstrates the usage of MSS Challenge-Response System
 * Service APIs for authenticating a device.
 *
 * To know more about this example project, please refer README.TXT in this 
 * project's folder.
 * 
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include <stdio.h>
#include "mss_uart.h"
#include "mss_sys_services.h"
#include "mss_comblk.h"

/*==============================================================================
 * Macro Definition
 */
#define DELAY_LOAD_VALUE            0x000A000UL
#define COREGPIO_BASE_ADDR          0x30000000U
#define CLEAR_DISPLAY               0x01u
#define DONT_CLEAR_DISPLAY          0x00u
#define ENTER_KEY                   13u
#define VALID_STATUS                0x00u
#define INVALID_STATUS              0x10u

/*==============================================================================
 * UART selection.
 * Replace the line below with this one if you want to use UART1 instead of
 * UART0:
 * mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
 * Global Variables.
 */
uint8_t g_keyaddr[32] = {0x00u};
uint8_t g_optype = 0x00u;
uint8_t g_path[16] = 
{
    0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u,
    0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u, 0x00u
};

const uint8_t *g_errror_message[] =
{
    (const uint8_t*)" Error - HRESP error occurred during MSS transfer.\r\n",
    (const uint8_t*)" Error - License not available in device.\r\n",
    (const uint8_t*)" Error - Service disabled by factory security.\r\n",
    (const uint8_t*)" Error - Service disabled by user security.\r\n",
    (const uint8_t*)" Error - Unknown.\r\n"
};

const uint8_t g_separator[] =
"\r\n======================================================================";

/*==============================================================================
 * Private function declaration.
 */
static void get_optype(void);
static void get_path(void);
static void display_hex_values(const uint8_t* in_buffer, uint32_t byte_length);
static void display_message(const uint8_t * p_msg, uint16_t msg_size, uint8_t clear_flag);
static void cli_init(void);
static uint8_t get_hex_byte(void);
static void display_error_info(uint8_t status);

/*------------------------------------------------------------------------------
 * main function.
 */
int main(void)
{
    uint8_t status = 0u;
    uint8_t rx_buff[1] = {0x0u};
    uint8_t rx_size = 1u;
    const uint8_t title1[] =
      " \r\n Challenge-Response System Service Example Project \r\n";

    /*System Services Driver Initialization.*/
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);

    /*Initialize command line interface and display message over UART.*/
    cli_init();

    display_message(title1, sizeof(title1), CLEAR_DISPLAY);

    do
    {
        if(rx_size > 0u)
        {
            rx_size = 0u;

            /*Get the Operational type and path from the user.*/
            get_optype();
            get_path();

            /*Send the challenge to G4M controller*/
            status = MSS_SYS_challenge_response(g_keyaddr, g_optype, g_path);

            /*Display the encrypted data in Hex Format*/
            if(MSS_SYS_SUCCESS == status)
            {
                MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                MSS_UART_polled_tx_string(gp_my_uart,  (const uint8_t *)"\r\n Challenge-Response data:\r\n");
                display_hex_values(g_keyaddr, sizeof(g_keyaddr));
            }
            else
            {
                MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Challenge-Response Failed.\r\n");
                display_error_info(status);
            }
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\n\r Press any key to run the service again");
        }

        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
    }while(1);
}

/******************************************************************************
 * Handle hexadecimal number input from the user.
 *****************************************************************************/
uint8_t get_hex_byte(void)
{
    uint8_t rx_char = 0u;
    uint8_t nb_rx_digit = 0u;
    size_t rx_size;
    uint8_t hex_byte = 0u;

    while(nb_rx_digit < 2u)
    {
        rx_size = MSS_UART_get_rx(gp_my_uart, &rx_char, sizeof(rx_char));

        if(rx_size > 0u)
        {
            if((rx_char >= '0') && (rx_char <= '9'))
            {
                hex_byte = (hex_byte * 16u) + (rx_char - '0');
                MSS_UART_polled_tx(gp_my_uart, &rx_char, sizeof(rx_char));
                nb_rx_digit++;
            }
            else if((rx_char >= 'a') && (rx_char <= 'f'))
            {
                hex_byte = (hex_byte * 16u) + (rx_char - 'a') + 10u;
                MSS_UART_polled_tx(gp_my_uart, &rx_char, sizeof(rx_char));
                nb_rx_digit++;
            }
            else if((rx_char >= 'A') && (rx_char <= 'F'))
            {
                hex_byte = (hex_byte * 16u) + (rx_char - 'A') + 10u;
                MSS_UART_polled_tx(gp_my_uart, &rx_char, sizeof(rx_char));
                nb_rx_digit++;
            }
        }
    }

    return hex_byte;
}
/******************************************************************************
 * Read Operational Type input from terminal
 *****************************************************************************/
static void get_optype(void)
{
    const uint8_t title[] =
     "\n \r Enter the 7-bit operational type (as a hex byte, msb is ignored):0x";

    display_message(title, sizeof(title), DONT_CLEAR_DISPLAY);

    g_optype = get_hex_byte();
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Selected Operational type is");
    display_hex_values(&g_optype, sizeof(g_optype));
}

/******************************************************************************
 * Read input - path from the terminal
 *****************************************************************************/
static void get_path(void)
{
    uint8_t complete = 0u;
    uint8_t count = 0u;

    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" \n\r Enter the 128 bit path variable (as hex Bytes, LS Byte first):\r\n");

    for(count = 0u; count < 16u; count++)
    {
        g_path[count] = 0x00u;
    }

    /*--------------------------------------------------------------------------
     * Read the path sent by user and store it.
     */
    count = 0u;

    while(!complete)
    {
        if(count < 16u)
        {
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" 0x");
            g_path[count] = get_hex_byte();
            count++;
            if(count == 8u)
            {
                MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n");
            }
        }
        else
        {
            complete = 1u;
        }
    }
}

/******************************************************************************
  * Display content of buffer passed as parameter as hex values
 *****************************************************************************/
static void display_hex_values
(
    const uint8_t* in_buffer,
    uint32_t byte_length
)
{
    uint8_t display_buffer[128];
    uint32_t inc;

    if(byte_length > 16u)
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n");
    }

    for(inc = 0u; inc < byte_length; ++inc)
    {
        if((inc > 1u) && (0u == (inc % 8u)))
        {
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n");
        }
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)" 0x");
        snprintf((char *)display_buffer, sizeof(display_buffer), "%02x", in_buffer[inc]);
        MSS_UART_polled_tx_string(gp_my_uart, display_buffer);
    }
}

/******************************************************************************
  * Display Message
 *****************************************************************************/
static void display_message
(
    const uint8_t * p_msg, 
    uint16_t msg_size, 
    uint8_t clear_flag
)
{
    uint8_t clear_screen = 0x0Cu;

    if(clear_flag)
    {
        MSS_UART_polled_tx(gp_my_uart, &clear_screen, sizeof(clear_screen));
    }

    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
    MSS_UART_polled_tx(gp_my_uart, p_msg, msg_size);
}

/******************************************************************************
 * Initialize the UART hardware used by the command line interface.
 *****************************************************************************/
static void cli_init(void)
{
    /* Initialize and configure UART. */
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
}

/******************************************************************************
 * Display error message.
 *****************************************************************************/
static void display_error_info(uint8_t status)
{
    switch(status)
    {
        case MSS_SYS_MEM_ACCESS_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[0]);
            break;
        
        case MSS_SYS_SERVICE_NOT_LICENSED:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[1]);
            break;
        
        case MSS_SYS_SERVICE_DISABLED_BY_FACTORY:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[2]);
            break;
        
        case MSS_SYS_SERVICE_DISABLED_BY_USER:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[3]);
            break;
        
        default:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[4]);
            break;
    }
}

