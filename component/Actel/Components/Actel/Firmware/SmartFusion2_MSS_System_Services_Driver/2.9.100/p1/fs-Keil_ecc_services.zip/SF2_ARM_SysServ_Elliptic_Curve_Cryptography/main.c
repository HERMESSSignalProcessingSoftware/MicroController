/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * ECC system service example.
 *
 * Please refer to file README.TXT for further details about this example.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include <stdio.h>
#include <string.h>
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
***************** SmartFusion2 ECC Services Example ******************\r\n\
**********************************************************************\r\n\
 This example project exercises ECC services\r\n\
  - Press \"a\" to perform point addition.\r\n\
  - Press \"m\" to perform point multiplication.\r\n\
  - Press \"g\" to to generate a public key.\r\n\
----------------------------------------------------------------------\r\n";

const uint8_t g_separator[] =
"----------------------------------------------------------------------\r\n";

/*==============================================================================
  Command line interface defines.
 */
#define   ENTER                     0x0D
#define   MAX_KEY_CODE_SIZE         524u
#define   MAX_HEX_BYTE_PER_LINE     8u
#define   ASCII_16_CHARACTERS       16u
#define   ASCII_32_CHARACTERS       (ASCII_16_CHARACTERS * 2)
#define   ASCII_48_CHARACTERS       (ASCII_16_CHARACTERS * 3)
#define   ASCII_64_CHARACTERS       (ASCII_16_CHARACTERS * 4)
#define   ASCII_96_CHARACTERS       (ASCII_16_CHARACTERS * 6)
#define   ASCII_128_CHARACTERS      (ASCII_32_CHARACTERS * 8)
#define   ASCII_192_CHARACTERS      (ASCII_32_CHARACTERS * 12)
#define   DATA_LENGTH_48_BYTES      ASCII_48_CHARACTERS

/*==============================================================================
 * Global Variables.
 */
const uint8_t *g_errror_message[] =
{
    (const uint8_t*)"\r\n Error - HRESP error occurred during MSS transfer.",
    (const uint8_t*)"\r\n Error - License not available in device.",
    (const uint8_t*)"\r\n Error - Service disabled by factory security.",
    (const uint8_t*)"\r\n Error - Service disabled by user security.",
    (const uint8_t*)"\r\n Error - Unexpected error.",
    (const uint8_t*)"\r\n Error - Invalid status."
};

/*==============================================================================
  Private functions.
*/
static void perform_point_multiplication(void);
static void perform_point_addition(void);
static void display_hex_values(const uint8_t* in_buffer, uint32_t byte_length);
static void display_greeting(void);
static void clear_variable(uint8_t *p_var, uint16_t size);
static void display_error_info(uint8_t status);
static uint8_t convert_ascii_to_hex(uint8_t* arr, uint32_t length);
static uint8_t validate_input(uint8_t ascii_input);
static void get_point_p_value(uint8_t* p_point_p);
static void get_point_q_value(uint8_t* p_point_q);
static void get_point_d_value(uint8_t* p_point_d);
static void display_result_point_r(uint8_t* p_point_r);
static void display_result_point_q(uint8_t* p_point_q);
static void display_result(uint8_t* result, const uint8_t* msg);
static void generate_public_key(void);
static void display_public_key(uint8_t* p_public_key);
static void get_private_key(uint8_t* p_key);
static uint8_t get_inputs
(
    uint8_t* location,
    uint8_t size,
    const uint8_t* msg
);
static uint8_t get_data_from_uart
(
    uint8_t* src_ptr,
    uint8_t size,
    const uint8_t* msg
);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  Main function.
 */
int main()
{
    size_t rx_size;
    uint8_t rx_buff[1] = {0x00};
    
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);
    
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);

    /* Display greeting message. */
    display_greeting();
      
    for(;;)
    {
        /* Start command line interface if any key is pressed. */
        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0)
        {
            switch(rx_buff[0])
            {
                case 'a':
                case 'A':
                    perform_point_addition();
                break;
                
                case 'm':
                case 'M':
                    perform_point_multiplication();
                break;
                
                case 'g':
                case 'G':
                    generate_public_key();
                break;
                
                default:
                    display_greeting();
                break;
            }
        }
    }
}

/******************************************************************************
 * Perform Point Multiplication.
 *****************************************************************************/
static void perform_point_multiplication(void)
{
    uint8_t status = 0u;
    uint8_t d[48] = {0x00u};
    uint8_t p[96] = {0x00u};
    uint8_t q[96] = {0x00u};
    
    /* Get the 384 bit scalar input d. */
    get_point_d_value(d);
    
    /* Get the X and Y co-ordinate of input P from UART terminal. */
    get_point_p_value(p);
    
    status = MSS_SYS_ecc_point_multiplication(&d[0], &p[0], &q[0]);
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Service point multiplication successfully.");
        display_result_point_q(q);
    }
    else
    {
        /* Display service failure message along with error code. */
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Service point multiplication failed.");
        display_error_info(status);
    }
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\n\r Press any key to run the service again");
}

/******************************************************************************
 * Perform Point addition.
 *****************************************************************************/
static void perform_point_addition(void)
{
    uint8_t status = 0u;
    uint8_t p[96] = { 0x00u };
    uint8_t q[96] = { 0x00u };
    uint8_t r[96] = { 0x00u };
    
    /* Get the X and Y coordinates of input point P. */
    get_point_p_value(p);
    
    /* Get the X and Y coordinates of input point Q. */
    get_point_q_value(q); 
    
    status = MSS_SYS_ecc_point_addition(&p[0], &q[0], &r[0]);
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Service point addition successfully.");
        display_result_point_r(r);
    }
    else
    {
        /* Display service failure message along with error code. */
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Service point addition failed.");
        display_error_info(status);
    }
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\r Press any key to run the service again");
}

/******************************************************************************
 * Generate Public key.
 *****************************************************************************/
static void generate_public_key(void)
{
    uint8_t status = 0u;
    uint8_t base_point[96] = {0x00u};
    uint8_t private_key[48] = {0x00u};
    uint8_t public_key[96] = {0x00u};
    
    /* Get the 384 bit scalar input i.e private key. */
    get_private_key(private_key);
    
    /* Get base point G for NIST elliptic curve P-384. */
    MSS_SYS_ecc_get_base_point(base_point);
    
    status = MSS_SYS_ecc_point_multiplication(&private_key[0], &base_point[0], &public_key[0]);
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Public key generated successfully.");
        display_public_key(public_key);
    }
    else
    {
        /* Display service failure message along with error code. */
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n Public key generation failed.");
        display_error_info(status);
    }
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\n\r Press any key to run the service again");
}

/******************************************************************************
  * Read the value of input point P.
 *****************************************************************************/
static void get_point_p_value(uint8_t* p_point_p)
{
    uint8_t point_value[96] = { 0x00 };
    const uint8_t input_P_x_cordinate[] = "\n\r Enter the 48-bytes X coordinate of input point P:\n\r";
    const uint8_t input_P_y_cordinate[] = "\n\r Enter the 48-bytes Y coordinate of input point P:\n\r";
    
    /* Get the X coordinates of input point P. */
    get_inputs(point_value, ASCII_96_CHARACTERS, input_P_x_cordinate);
    memcpy(&p_point_p[0], &point_value[0], DATA_LENGTH_48_BYTES);
    
    /* Get the Y coordinates of input point P. */
    get_inputs(point_value, ASCII_96_CHARACTERS, input_P_y_cordinate);
    memcpy(&p_point_p[48], &point_value[0], DATA_LENGTH_48_BYTES);
}

/******************************************************************************
  * Read the value of input point Q.
 *****************************************************************************/
static void get_point_q_value(uint8_t* p_point_q)
{
    uint8_t point_value[96] = { 0x00 };
    const uint8_t input_Q_x_cordinate[] = "\n\r Enter the 48-bytes X coordinate of input point Q:\n\r";
    const uint8_t input_Q_y_cordinate[] = "\n\r Enter the 48-bytes Y coordinate of input point Q:\n\r";
    
    /* Get the X coordinates of input point Q. */
    get_inputs(point_value, ASCII_96_CHARACTERS, input_Q_x_cordinate);
    memcpy(&p_point_q[0], &point_value[0], DATA_LENGTH_48_BYTES);
    
    /* Get the Y coordinates of input point Q. */
    get_inputs(point_value, ASCII_96_CHARACTERS, input_Q_y_cordinate);
    memcpy(&p_point_q[48], &point_value[0], DATA_LENGTH_48_BYTES);
}
/******************************************************************************
  * Read the value of input point d.
 *****************************************************************************/
static void get_point_d_value(uint8_t* p_point_d)
{
    uint8_t point_value[96] = { 0x00 };
    const uint8_t input_d[] = "\n\r Enter the 384 bit input scaler d:\n\r";
    
    get_inputs(point_value, ASCII_96_CHARACTERS, input_d);
    memcpy(&p_point_d[0], &point_value[0], DATA_LENGTH_48_BYTES);
}

/******************************************************************************
  * Read the private key.
 *****************************************************************************/
static void get_private_key(uint8_t* p_key)
{
    uint8_t point_value[96] = { 0x00 };
    const uint8_t input_d[] = "\n\r Enter the 384 bit private key:\n\r";
    
    get_inputs(point_value, ASCII_96_CHARACTERS, input_d);
    memcpy(&p_key[0], &point_value[0], DATA_LENGTH_48_BYTES);
}

/******************************************************************************
  * Display the result value of point R.
 *****************************************************************************/
static void display_result_point_r(uint8_t* p_point_r)
{
    const uint8_t result_msg[] = "\r\n R result: \n\r";
    
    display_result(p_point_r, result_msg);
}

/******************************************************************************
  * Display the result value of point Q.
 *****************************************************************************/
static void display_result_point_q(uint8_t* p_point_q)
{
    const uint8_t result_msg[] = "\n\r Q result: \n\r";
    
    display_result(p_point_q, result_msg);
}

/******************************************************************************
  * Display the public key.
 *****************************************************************************/
static void display_public_key(uint8_t* p_public_key)
{
    const uint8_t result_msg[] = "\n\r Public key value: \n\r";
    
    display_result(p_public_key, result_msg);
}

/******************************************************************************
  * Display the error message.
 *****************************************************************************/
static void display_error_info(uint8_t status)
{
    switch(status)
    {
        case MSS_SYS_MEM_ACCESS_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[0]);
            break;
        
        case MSS_SYS_SERVICE_NOT_LICENSED:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[1]);
            break;
        
        case MSS_SYS_SERVICE_DISABLED_BY_FACTORY:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[2]);
            break;
        
        case MSS_SYS_SERVICE_DISABLED_BY_USER:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[3]);
            break;
            
        case MSS_SYS_UNEXPECTED_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[4]);
            break;
            
        default:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[5]);
            break;
    }
}

/******************************************************************************
  * Display content of buffer passed as parameter as hex values
 *****************************************************************************/
static void display_hex_values
(
    const uint8_t* in_buffer,
    uint32_t byte_length
)
{
    uint8_t display_buffer[128];
    uint32_t inc;
    
    if(byte_length > 16u)
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n");
    }
    
    for(inc = 0u; inc < byte_length; ++inc)
    {
        if((inc > 1u) && (0u == (inc % MAX_HEX_BYTE_PER_LINE)))
        {
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n");
        }
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)" 0x");
        snprintf((char *)display_buffer, sizeof(display_buffer), "%02x", in_buffer[inc]);
        MSS_UART_polled_tx_string(gp_my_uart, display_buffer);
    }
    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n");
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
}

/*==============================================================================
  Display the result of computation on UART terminal.
 */
static void display_result(uint8_t* result, const uint8_t* msg)
{
    MSS_UART_polled_tx_string(gp_my_uart, msg);
        
    /* Display the X coordinate value on UART terminal. */
    MSS_UART_polled_tx_string(gp_my_uart,
                          (const uint8_t*)" X coordinate value:");
    display_hex_values(&result[0], 48);
    
    /* Display the Y coordinate value on UART terminal. */
    MSS_UART_polled_tx_string(gp_my_uart,
                          (const uint8_t*)" Y coordinate value:");
    /* Display the computed result overs serial terminal. */
    display_hex_values(&result[48], 48);
}

/*==============================================================================
  Function to clear local variable and array.
 */
static void clear_variable(uint8_t *p_var, uint16_t size)
{
    uint16_t inc;
    
    for(inc = 0; inc < size; inc++)
    {
        *p_var = 0x00;
        p_var++;
    }
}

/*==============================================================================
  Function to get the input data from user.
 */
static uint8_t get_inputs
(
    uint8_t* location,
    uint8_t size,
    const uint8_t* msg
)
{
    uint8_t count = 0u;
    
    /* Clear the memory location. */
    clear_variable(location, size);

    /* Read the 16 bytes of input data from UART terminal. */
    count = get_data_from_uart(location, size, msg);

    /* Convert ASCII key to Hex format */
    convert_ascii_to_hex(location, size);
    
    return count;
}

/*==============================================================================
  Function to read data from UART terminal and stored it.
 */
static uint8_t get_data_from_uart
(
    uint8_t* src_ptr,
    uint8_t size,
    const uint8_t* msg
)
{
    uint8_t complete = 0u;
    uint8_t rx_buff[1];
    uint8_t rx_size = 0u;
    uint8_t count = 0u;
    
    MSS_UART_polled_tx_string(gp_my_uart, msg);
    
    /* Read the key size sent by user and store it. */
    count = 0u;
    while(!complete)
    {
        rx_size = MSS_UART_get_rx (gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0u)
        {
            /* Is it to terminate from the loop */
            if(ENTER == rx_buff[0])
            {
                complete = 1u;
            }
            /* Is entered key valid */
            else if(validate_input(rx_buff[0]) != 1u)
            {
                MSS_UART_polled_tx(gp_my_uart, rx_buff, sizeof(rx_buff));
                MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Invalid input.");
                MSS_UART_polled_tx_string(gp_my_uart, msg);
                complete = 0u;
                count = 0u;
                clear_variable(src_ptr, 4);
            }
            else
            {
                src_ptr[count] = rx_buff[0];
                
                /* Switching to next line after every 8 bytes */
                if(((count % 16u) == 0x00u) && (count > 0x00u) && (complete != 0x01u))
                {
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\r");
                }

                if((count % 2u) == 0u)
                {
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" 0x"); 
                }
                MSS_UART_polled_tx(gp_my_uart, rx_buff, sizeof(rx_buff));
                count++;
                if(size == count)
                {
                   complete = 1u;
                }
            }
        }
    }
    
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t *)"\n\r");
    
    return count;
}

/*==============================================================================
  Convert ASCII to hex.
 */
static uint8_t convert_ascii_to_hex(uint8_t* arr, uint32_t length)
{
    uint32_t inc = 0u;
    uint8_t nb_digit = 0u;
    uint8_t hex_byte = 0u;
    uint8_t error_flag = 0u;
    uint8_t* src_ptr = arr;
    uint8_t* dst_ptr = arr;
    
    for(inc = 0; inc < length; inc++)
    {
        if((*src_ptr >= '0') && (*src_ptr <= '9'))
        {
            hex_byte = (hex_byte * 16u) + (*src_ptr - '0');
            *src_ptr = 0u;
            src_ptr++;
            nb_digit++;
        }
        else if((*src_ptr >= 'a') && (*src_ptr <= 'f'))
        {
            hex_byte = (hex_byte * 16u) + (*src_ptr - 'a') + 10u;
            *src_ptr = 0u;
            src_ptr++;
            nb_digit++;
        }
        else if((*src_ptr >= 'A') && (*src_ptr <= 'F'))
        {
            hex_byte = (hex_byte * 16u) + (*src_ptr - 'A') + 10u;
            *src_ptr = 0u;
            src_ptr++;
            nb_digit++;
        }
        else if(*src_ptr != 0x00u)
        {
            MSS_UART_polled_tx_string(gp_my_uart,
                                      (const uint8_t *)"\r\n Invalid data.");
            error_flag = 1u;
            break;
        }
        
        if(nb_digit >= 2u)
        {
            *dst_ptr = hex_byte;
            nb_digit = 0u;
            hex_byte = 0u;
            dst_ptr++;
        }
    }
    
    if(nb_digit == 1u)
    {
      *dst_ptr = (hex_byte * 16u);
    }
    
    return error_flag;
}

/*==============================================================================
  Validate the input ASCII value .
 */
static uint8_t validate_input(uint8_t ascii_input)
{
    uint8_t valid_key = 0u;
    
    if(((ascii_input >= 'A') && (ascii_input <= 'F')) ||       \
       ((ascii_input >= 'a') && (ascii_input <= 'f')) ||       \
       ((ascii_input >= '0') && (ascii_input <= '9')))
    {
       valid_key = 1u;
    }
    else
    {
       valid_key = 0u;
    }
    
    return valid_key;
}
