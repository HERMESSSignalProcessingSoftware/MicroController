/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * Retrieve secondary device certificate using System Services.
 *
 * Please refer to file README.TXT for further details about this example.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include <stdio.h>
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
******* SmartFusion2 Read Secondary Device Certificate Example *******\r\n\
**********************************************************************\r\n\
This example project displays information about the secondary device \r\n\
certificate retrieved using the SmartFusion2 System Services.\r\n\
    - MSS_SYS_get_secondary_device_certificate()\r\n\
NOTE: Secondary device certificate is only available on G4X device.\r\n\
----------------------------------------------------------------------\r\n";

const uint8_t g_separator[] =
"\r\n----------------------------------------------------------------------\r\n";

/*==============================================================================
  Private functions.
 */
static void display_greeting(void);
static void display_hex_values
(
    const uint8_t * in_buffer,
    uint32_t byte_length
);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  Main function.
 */
int main()
{
    uint8_t secondary_device_certificate[640];
    uint8_t status;
    
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);
    
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
        
    /* Display greeting message. */
    display_greeting();

    /*--------------------------------------------------------------------------
     * Secondary Device certificate.
     */
    status = MSS_SYS_get_secondary_device_certificate(secondary_device_certificate);
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"Secondary Device certificate: ");
        display_hex_values(secondary_device_certificate, sizeof(secondary_device_certificate));
    }
    else
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"Service get secondary device certificate failed.\r\n");
        
        if(MSS_SYS_MEM_ACCESS_ERROR == status)
        {
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"Error - MSS memory access error.");
        }
    }

    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
    
    for(;;)
    {
        ;
    }
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
}

/*==============================================================================
  Display content of buffer passed as parameter as hex values
 */
static void display_hex_values
(
    const uint8_t * in_buffer,
    uint32_t byte_length
)
{
    uint8_t display_buffer[128];
    uint32_t inc;
    
    if(byte_length > 16u)
    {
        MSS_UART_polled_tx_string( gp_my_uart,(const uint8_t*)"\r\n" );
    }
    
    for(inc = 0; inc < byte_length; ++inc)
    {
        if((inc > 1u) &&(0u == (inc % 16u)))
        {
            MSS_UART_polled_tx_string( gp_my_uart,(const uint8_t*)"\r\n" );
        }
        snprintf((char *)display_buffer, sizeof(display_buffer), "%02x ", in_buffer[inc]);
        MSS_UART_polled_tx_string(gp_my_uart, display_buffer);
    }
}
