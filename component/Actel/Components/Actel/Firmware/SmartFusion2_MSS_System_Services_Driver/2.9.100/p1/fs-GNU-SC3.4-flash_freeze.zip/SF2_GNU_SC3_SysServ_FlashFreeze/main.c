/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * Flash Freeze system service example.
 *
 * Please refer to file README.TXT for further details about this example.
 *
 * SVN $Revision: 8689 $
 * SVN $Date: 2016-11-27 18:22:17 +0530 (Sun, 27 Nov 2016) $
 */
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_rtc/mss_rtc.h"

/*------------------------------------------------------------------------------
  RTC prescaler value.
  Uncomment the value corresponding to your hardware configuration.
 */
/* #define RTC_PRESCALER    (32768u - 1u) */    /* 32KHz crystal is RTC clock source. */
/* #define RTC_PRESCALER    (1000000u - 1u)  */ /* 1MHz clock is RTC clock source. */
/* #define RTC_PRESCALER    (25000000u - 1u) */ /* 25MHz clock is RTC clock source. */
#define RTC_PRESCALER    (50000000u - 1u)  /* 50MHz clock is RTC clock source. */

/*------------------------------------------------------------------------------
  Setting the RTC timeout duration to 10 sec
*/
#define FLASH_FREEZE_TIMEOUT    10u

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
********* SmartFusion2 Flash Freeze System Services Example **********\r\n\
**********************************************************************\r\n\
This example project exercises the Flash Freeze system services.\r\n\
Press \"f\" to enter Flash Freeze.\r\n\
----------------------------------------------------------------------";

const uint8_t g_ff_request_msg[] =
"\r\n\r\n Requesting Flash Freeze shutdown.";

const uint8_t g_ff_shutdown_msg[] =
"\r\n\r\n\
----------------------------------------------------------------------\r\n\
!!!!!!!!!!!!!!!!!!!!!!! Flash Freeze shutdown. !!!!!!!!!!!!!!!!!!!!!!!\r\n\
----------------------------------------------------------------------";

const uint8_t g_ff_exit_msg[] =
"\r\n\r\n\
----------------------------------------------------------------------\r\n\
!!!!!!!!!!!!!!!!!!!!!!!! Flash Freeze exited. !!!!!!!!!!!!!!!!!!!!!!!!\r\n\
----------------------------------------------------------------------";

const uint8_t g_rtc_wakeup_exit_msg[] =
"\r\n\r\n\
----------------------------------------------------------------------\r\n\
!!!!!!!!!!!!!!!!!!!!!!!!! RTC wake up event. !!!!!!!!!!!!!!!!!!!!!!!!!\r\n\
----------------------------------------------------------------------";

const uint8_t g_ff_success_msg[] =
"\r\n\r\n Flash Freeze system service request success.";

const uint8_t *g_errror_message[] =
{
    (const uint8_t*)"\r\n Error - Service disabled by factory security.",
    (const uint8_t*)"\r\n Error - Service disabled by user security.",
    (const uint8_t*)"\r\n Error - Unexpected error.",
    (const uint8_t*)"\r\n Error - Invalid status.",
    (const uint8_t*)"\r\n Error - Clock divisor error."
};

volatile uint32_t g_ff_request_success_event = 0U;
volatile uint32_t g_flash_freeze_shutdown_event = 0U;
volatile uint32_t g_rtc_wakeup_event = 0U;
volatile uint32_t g_flash_freeze_exit_event = 0U;

/*==============================================================================
  Private functions.
 */
static void display_greeting(void);
static void init_uart(void);
static void sys_services_event_handler(uint8_t opcode, uint8_t response);
static void display_error_info(uint8_t status);
static void flash_freeze_states(void);

static void wait_for_switch_to_flash_freeze(void);
static void wait_for_flash_freeze_exit(void);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  Main function.
 */
int main(void)
{
    /* 
     * Initialize peripherals.
     */
    MSS_SYS_init(sys_services_event_handler);
    MSS_RTC_init(MSS_RTC_BINARY_MODE, RTC_PRESCALER);
    init_uart();

    /*
     * Display greeting message.
     */
    display_greeting();
    
    /*
     * Foreground loop.
     */
    for(;;)
    {
        size_t rx_size;
        uint8_t rx_buff[1];
        int8_t tx_complete;
        
        /*
         * Wait for the "f" key to be pressed in the host's terminal window.
         */
        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0)
        {
            if ('f' == rx_buff[0])
            {
                uint8_t status;
                
                /*
                 * Set the RTC to generate a single shot alarm to exit Flash Freeze.
                 */
                MSS_RTC_reset_counter();
                MSS_RTC_set_binary_count_alarm(FLASH_FREEZE_TIMEOUT,
                                               MSS_RTC_SINGLE_SHOT_ALARM);
                MSS_RTC_enable_irq();
                MSS_RTC_start();
                
                /*
                 * Display a message indicating that Flash Freeze shutdown was
                 * requested.
                 * Please note that we must wait until the last character has been
                 * transmitted by the UART. Entering flash freeze while the message
                 * is sent by the UART would result in a corrupted message being
                 * sent because of the switch to the standby clock taking place as
                 * part of the Flash Freeze shutdown. The switch to the standby
                 * clock would result in the UART baud rate changing while the
                 * message is sent since the frequency clocking the UART would
                 * change.
                 */
                MSS_UART_polled_tx_string(gp_my_uart, g_ff_request_msg);
                do {
                    tx_complete = MSS_UART_tx_complete(gp_my_uart);
                } while(0 == tx_complete);
                
                /*
                 * Request Flash Freeze shutdown.
                 */
                status = MSS_SYS_flash_freeze(MSS_SYS_FPGA_POWER_DOWN);
                
                if(MSS_SYS_SUCCESS == status)
                {
                    g_ff_request_success_event = 1U;
                }
                else
                {
                    MSS_RTC_stop();
                    display_error_info(status);
                }
            }
        }
        else
        {
            /*
             * Handle the system state changes resulting from entering and
             * exiting Flash*Freeze.
             */
            flash_freeze_states();
        }
    }
}

/*==============================================================================
  Flash*Freeze state changes.
 */
static void flash_freeze_states(void)
{
    int8_t tx_complete;
    
    if (g_ff_request_success_event != 0U)
    {
        /*
         * We know that the Flash*Freeze request was successful. We must wait
         * until the Flash*Freeze event has been received before doing anything
         * involving peripheral clocks. The system's clock is going to switch at
         * some point between calling the MSS_SYS_flash_freeze() function and
         * receiving the Flash*Freeze shutdown event. It is unsafe to use
         * peripherals like UARTs during that time.
         */
        g_ff_request_success_event = 0U;
        
        wait_for_switch_to_flash_freeze();
        
        MSS_UART_polled_tx_string(gp_my_uart, g_ff_success_msg);
        do {
            tx_complete = MSS_UART_tx_complete(gp_my_uart);
        } while(0 == tx_complete);
    }
    
    if (g_flash_freeze_shutdown_event != 0U)
    {
        /*
         * Flash*Freeze shutdown has taken place. It is now safe to use
         * peripherals. The system is now operating from the standby clock.
         */
        g_flash_freeze_shutdown_event = 0U;

        MSS_UART_polled_tx_string(gp_my_uart, g_ff_shutdown_msg);
        do {
            tx_complete = MSS_UART_tx_complete(gp_my_uart);
        } while(0 == tx_complete);
    }
    
    if (g_rtc_wakeup_event != 0U)
    {
        /*
         * The RTC wake-up event occured. The System Controller is going to take
         * the system out of Flash*Freeze. The system's clock is going to switch
         * from the standby clock to the normal operations clock. It is unsafe
         * to use peripherals during the clock switch. We must wait until the
         * Flash*Freeze exit event takes place before using peripherals like the
         * UART.
         */
        g_rtc_wakeup_event = 0U;
        
        wait_for_flash_freeze_exit();
       
        MSS_UART_polled_tx_string(gp_my_uart, g_rtc_wakeup_exit_msg);
        do {
            tx_complete = MSS_UART_tx_complete(gp_my_uart);
        } while(0 == tx_complete);
    }
    
    if (g_flash_freeze_exit_event != 0U)
    {
        /*
         * Flash*Freeze exit has taken place. It is now safe to use peripherals.
         * The system is now operating from the normal clock.
         */
        g_flash_freeze_exit_event = 0U;
        
        MSS_UART_polled_tx_string(gp_my_uart, g_ff_exit_msg);
    }
}

/*==============================================================================
  Wait for Flash*Freeze shut down. This is used by the application to wait for
  the system clock to switch to the standby clock.
 */
static void wait_for_switch_to_flash_freeze(void)
{
    volatile uint32_t delay = 10000;
    while ((0U == g_flash_freeze_shutdown_event) && (delay != 0U))
    {
        --delay;
    }
}

/*==============================================================================
  Wait for Flash*Freeze to exit. This is used by the application to wait for the
  system clock to be restore from the standby clock to main system clock.
 */
static void wait_for_flash_freeze_exit(void)
{
    volatile uint32_t delay = 10000;
    while ((0U == g_flash_freeze_exit_event) && (delay != 0U))
    {
        --delay;
    }
}

/*==============================================================================
  System Services event handler.
 */
static void sys_services_event_handler(uint8_t opcode, uint8_t response)
{
    if(FLASH_FREEZE_SHUTDOWN_OPCODE == opcode)
    {
        g_flash_freeze_shutdown_event = 1U;
        
        /* Re-initialize the UART. */
        init_uart();
    }
    else if(FLASH_FREEZE_EXIT_OPCODE == opcode)
    {
        g_flash_freeze_exit_event = 1U;
        
        /* Re-initialize the UART. */
        init_uart();
    }
}

/*==============================================================================
  Initialize the UART.
  This function needs to be called when the UART clock frequency changes as a
  result of switching between the main and standby clocks. Entering Flash Freeze
  results in the system becoming clocked by the standby clock. Exiting Flash
  Freeze results in the system becoming clocked by the main system clock.
 */
static void init_uart(void)
{
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
}

/*==============================================================================
  RTC wake up interrupt service routine.
 */
void RTC_Wakeup_IRQHandler(void)
{
    g_rtc_wakeup_event = 1U;
    
    MSS_RTC_clear_irq();
}

/*==============================================================================
  Display error message.
 */
static void display_error_info(uint8_t status)
{
    switch(status)
    {
        case MSS_SYS_SERVICE_DISABLED_BY_FACTORY:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[0]);
        break;
        
        case MSS_SYS_SERVICE_DISABLED_BY_USER:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[1]);
        break;
        
        case MSS_SYS_UNEXPECTED_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[2]);
        break;
        
        case MSS_SYS_CLK_DIVISOR_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[4]);
        break;
        
        default:
            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)g_errror_message[3]);
        break;
    }
}

