/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * This Example Project demonstrates the usage of MSS System Service APIs to
 * destroys sensitive information on the device.
 *
 * To know more about this example project Please refer README.TXT in this
 * project's folder.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include "core_gpio.h"
#include "mss_uart.h"
#include "mss_sys_services.h"

/*-----------------------------------------------------------------------------
 * Delay loop down counter load value.
 */
#define DELAY_LOAD_VALUE            0x000A000UL

/*-----------------------------------------------------------------------------
 * Core GPIO Base address.
 */
#define COREGPIO_BASE_ADDR          0x30000000U

/*-----------------------------------------------------------------------------
 * CoreGPIO instance data.
 */
gpio_instance_t g_gpio;

/*-----------------------------------------------------------------------------
 * Function Declaration.
 */
void cli_init(void);
void display_message(const uint8_t* p_msg, uint16_t msg_size, uint8_t clear_flag);

/*-----------------------------------------------------------------------------
 * LED blink function
 */
void led_blink(void)
{
    static int32_t delay_count = DELAY_LOAD_VALUE;
    uint32_t gpio_pattern;

    /*-------------------------------------------------------------------------
     * Decrement delay counter.
     */
    --delay_count;

    /*-------------------------------------------------------------------------
     * Check if delay expired.
     */
    if (delay_count <= 0)
    {
        /*-------------------------------------------------------------------------
         * Reload delay counter.
         */
        delay_count = DELAY_LOAD_VALUE;

        /*-------------------------------------------------------------------------
         * Toggle GPIO output pattern by doing an exclusive OR of all
         * pattern bits with ones.
         */
        gpio_pattern = GPIO_get_outputs(&g_gpio);
        gpio_pattern ^= 0x0000000F;
        GPIO_set_outputs(&g_gpio, gpio_pattern);
    }
}

/*------------------------------------------------------------------------------
 * main function.
 */
int main(void)
{
    const uint8_t title[] = "\n\r Zeroization Example Project \
            \n\r=================================================================== \
            \n \r Zeroization will delete sensitive information on the blocks for \
            \n \r which zeroization service is enabled. The level of information \
            \n \r destroyed is configured as part of hardware flow of the design \
            \n \r programmed into the device. The zeroization service will destroy \
            \n \r all user configuration data, user keys, user security settings, \
            \n \r NVM, SRAM, FPGA system controller memory, fabric and crypto-engine \
            \n \r registers.\
            \n\n\r Note: Once started, zeroization can not be stopped and all \
            \n \r applicable information will get erased. Zeroization will take \
            \n \r 1-2 min to complete. After Zeroization, LED will not blink \
            \n \r and no message will be displayed on terminal window. To verify \
            \n \r the Zeroization was successful, try loading the application  \
            \n \r program using debugger again. It should fail, as applicable \
            \n \r block has been erased.\n\r";

   const uint8_t title1[] = " \n\r Press '1' to execute Zeroization";
   const uint8_t title2[] = " \n\r Key Press ";
   uint8_t rx_char;
   size_t rx_size = 0u;

   /*-------------------------------------------------------------------------
    * Initialize the CoreGPIO driver with the base address of the CoreGPIO
    * instance to use and the initial state of the outputs.
    */
    GPIO_init(&g_gpio, COREGPIO_BASE_ADDR, GPIO_APB_32_BITS_BUS);

    /*-------------------------------------------------------------------------
     * Configure the GPIO pin.
     */
    GPIO_config(&g_gpio, GPIO_0, GPIO_OUTPUT_MODE);
    GPIO_config(&g_gpio, GPIO_1, GPIO_OUTPUT_MODE);
    GPIO_config(&g_gpio, GPIO_2, GPIO_OUTPUT_MODE);
    GPIO_config(&g_gpio, GPIO_3, GPIO_OUTPUT_MODE);

    /*-------------------------------------------------------------------------
     * System Services Driver Initialization.
     */
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);

    /*-------------------------------------------------------------------------
     * Initialize command line interface and display message over UART.
     */
    cli_init();
    display_message(title, sizeof(title),1u);
    display_message(title1, sizeof(title1),0u);
    while(1)
    {
        led_blink();
        rx_size = MSS_UART_get_rx (&g_mss_uart0, &rx_char, sizeof(rx_char));
        if(rx_size > 0u)
        {
            switch(rx_char)
            {
                case '1':
                        display_message(title2, sizeof(title2),0u);
                        MSS_SYS_zeroize_device();
                    break;
                    
                default:
                    /* Ignore received character. */
                    break;
            }
            rx_size = 0u;
        }
    }
}

/*-----------------------------------------------------------------------------
 * Initialize the UART hardware used by the command line interface
 */
void cli_init(void)
{
    /* Initialize and configure UART. */
    MSS_UART_init
        (&g_mss_uart0,
         MSS_UART_115200_BAUD,
         MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
}

/*-----------------------------------------------------------------------------
 * Display Message
 */
void display_message
(
    const uint8_t* p_msg, 
    uint16_t msg_size, 
    uint8_t clear_flag
)
{
    uint8_t delim1[] = "\n\r======================================================================";
    uint8_t clear_screen = 0x0Cu;
    if(clear_flag != 0u)
    {
        MSS_UART_polled_tx(&g_mss_uart0, &clear_screen, sizeof(clear_screen));
    }
    MSS_UART_polled_tx(&g_mss_uart0, delim1, sizeof(delim1));
    MSS_UART_polled_tx(&g_mss_uart0, p_msg, msg_size);
}


