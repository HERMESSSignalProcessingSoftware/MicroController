/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * Non Deterministic Random Bit Generator example.
 *
 * Please refer to file README.TXT for further details about this example.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include <stdio.h>
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
***** SmartFusion2 Random Bit Generator System Services Example ******\r\n\
**********************************************************************\r\n\
 This example project exercises the random bit generator system\r\n\
 services.\r\n\
  - Press \"i\" to instantiate random numbers.\r\n\
  - Press \"s\" to perform self test.\r\n\
  - Press \"g\" to generate random numbers.\r\n\
  - Press \"r\" to release the NDRBG generator.\r\n\
  - Press \"R\" to reset the NDRBG service.\r\n\
----------------------------------------------------------------------\r\n";

const uint8_t g_separator[] =
"\r\n----------------------------------------------------------------------\r\n";

/*==============================================================================
  Command line interface defines.
 */
#define INVALID_USER_INPUT  -1
#define ENTER   0x0D

/*==============================================================================
 * Global Variables.
 */
const uint8_t *g_errror_message[] =
{
    (const uint8_t*)"\r\n Error - Catastrophic Error.",
    (const uint8_t*)"\r\n Error - Max Instantiations Exceeded.",
    (const uint8_t*)"\r\n Error - Invalid Handle.",
    (const uint8_t*)"\r\n Error - Generate Request Too Big.",
    (const uint8_t*)"\r\n Error - Max Length of Additional Data Exceeded.",
    (const uint8_t*)"\r\n Error - HRESP error occurred during MSS transfer.",
    (const uint8_t*)"\r\n Error - License not available in device.",
    (const uint8_t*)"\r\n Error - Service disabled by factory security.",
    (const uint8_t*)"\r\n Error - Service disabled by user security.",
    (const uint8_t*)"\r\n Error - Unexpected error.",
    (const uint8_t*)"\r\n Error - Invalid status."
};

uint8_t drbg_handle[3];

/*==============================================================================
  Private functions.
 */
static void display_greeting(void);
static void generate_random_bits(uint8_t drbg_handle);
static void release_drbg_service(uint8_t* drbg_handle);
static int32_t get_number_from_user(void);
static void reset_drbg_service(void);
static void display_hex_values
(
    const uint8_t * in_buffer,
    uint32_t byte_length
);
static void display_error_info(uint8_t status, uint8_t invalid);
static uint8_t select_drbg_handle(void);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  Main function.
 */
int main()
{
    uint8_t drbg_handle_no;
    uint8_t status;
    size_t rx_size;
    uint8_t rx_buff[1];
    
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);
    
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);

    /* Display greeting message. */
    display_greeting();
      
    for(;;)
    {
        /* Start command line interface if any key is pressed. */
        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0)
        {
            switch(rx_buff[0])
            {
                case 'i':
                    drbg_handle_no = select_drbg_handle();
                    status = MSS_SYS_nrbg_instantiate(0, 0, &drbg_handle[drbg_handle_no]);
                    if(MSS_SYS_SUCCESS == status)
                    {
                        MSS_UART_polled_tx_string(gp_my_uart,
                                                  (const uint8_t*)"\r\n DRBG reserve successful.");
                    }
                    else
                    {
                        MSS_UART_polled_tx_string(gp_my_uart,
                                                  (const uint8_t*)"\r\n DRBG reserve failure.");
                        display_error_info(status, 0u);
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case 's':
                    status = MSS_SYS_nrbg_self_test();
                    if(MSS_SYS_SUCCESS == status)
                    {
                        MSS_UART_polled_tx_string(gp_my_uart,
                                                  (const uint8_t*)" DRBG self test successful.");
                    }
                    else
                    {
                        MSS_UART_polled_tx_string(gp_my_uart,
                                                  (const uint8_t*)" DRBG self test failure.");
                        display_error_info(status, 1u);
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case 'g':
                    drbg_handle_no = select_drbg_handle();
                    generate_random_bits(drbg_handle[drbg_handle_no]);
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case 'r':
                    drbg_handle_no = select_drbg_handle();
                    release_drbg_service(&drbg_handle[drbg_handle_no]);
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                case 'R':
                    reset_drbg_service();
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    break;
                    
                default:
                    break;
            }
        }
    }
}

/*==============================================================================
  Perform the DRGB un-instantiation and display the status on UART terminal.
 */
static void release_drbg_service(uint8_t* drbg_handle)
{
    uint8_t status;
    
    /* Removes a previously instantiated DRBG */
    status = MSS_SYS_nrbg_uninstantiate(*drbg_handle);
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n DRBG release successful.");
       /* Reset specific DRBG instances. */ 
        *drbg_handle = 0xFF;
        
    }
    else
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)"\r\n DRBG release failure.");
        display_error_info(status, 1u);
    }
    
}

/*==============================================================================
  Perform DRBG reset and display the status on UART terminal.
 */
static void reset_drbg_service(void)
{
    uint8_t status;
    
    /* Removes all DRBG instantiations and resets the DRBG */
    status = MSS_SYS_nrbg_reset();
    if(MSS_SYS_SUCCESS == status)
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)" DRBG reset successful.");
        /* Reset all the DRBG instances. */
        drbg_handle[0] = 0xFF;
        drbg_handle[1] = 0xFF;
        drbg_handle[2] = 0xFF;
    }
    else
    {
        MSS_UART_polled_tx_string(gp_my_uart,
                                  (const uint8_t*)" DRBG reset failure.");
        display_error_info(status, 1u);
    }
    
}
/*==============================================================================
  Generate Random number and display the status and generated number on UART terminal.
 */
#define MAX_NB_OF_RANDOM_BYTES      128

static void generate_random_bits(uint8_t drbg_handle)
{
    uint32_t nb_of_bytes;
    uint8_t random_bytes[MAX_NB_OF_RANDOM_BYTES];
    uint8_t status;
    
    MSS_UART_polled_tx_string(gp_my_uart,
                              (const uint8_t *)"\r\n Number of random bytes to generate (1 to 128): ");
    
    nb_of_bytes = get_number_from_user();
    
    if((nb_of_bytes >= 1) && (nb_of_bytes <= MAX_NB_OF_RANDOM_BYTES))
    {
        /* Generate random bits */
        status = MSS_SYS_nrbg_generate(random_bytes,    /* p_requested_data */
                                       0,               /* p_additional_input */
                                       nb_of_bytes,     /* requested_length */
                                       0,               /* additional_input_length */
                                       0,               /* pr_req */
                                       drbg_handle);    /* drbg_handle */
        if(MSS_SYS_SUCCESS == status)
        {
            MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\r\n DRBG generate successful: ");
            display_hex_values(random_bytes, nb_of_bytes);
        }
        else
        {
            MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\r\n DRBG generate failure.");
            display_error_info(status, 0u);
        }
    }
    else
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n\r\n Invalid entry.");
    }
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
}

/*==============================================================================
  Retrieve a number typed by the user.
 */
static int32_t get_number_from_user(void)
{
    int32_t user_input = 0u;
    uint8_t rx_buff[1];
    uint8_t complete = 0u;
    size_t rx_size;

    while(!complete)
    {
        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0)
        {
            MSS_UART_polled_tx(gp_my_uart, rx_buff, sizeof(rx_buff));
            if(ENTER == rx_buff[0])
            {
                complete = 1u;
            }
            else if((rx_buff[0] >= '0') && (rx_buff[0] <= '9'))
            {
                user_input = (user_input * 10u) + (rx_buff[0] - '0');
            }
            else
            {
                user_input = INVALID_USER_INPUT;
                complete = 1u;
            }
        }
    }
    return user_input;
}

/*==============================================================================
  Display content of buffer passed as parameter as hex values.
 */
static void display_hex_values
(
    const uint8_t * in_buffer,
    uint32_t byte_length
)
{
    uint8_t display_buffer[128];
    uint32_t inc;
    
    if(byte_length > 16u)
    {
        MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\r\n");
    }
    
    for(inc = 0; inc < byte_length; ++inc)
    {
        if((inc > 1u) &&(0u == (inc % 16u)))
        {
            MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\r\n");
        }
        snprintf((char *)display_buffer, sizeof(display_buffer), " %02x", in_buffer[inc]);
        MSS_UART_polled_tx_string(gp_my_uart, display_buffer);
    }
}

/*==============================================================================
  Display error message.
 */
static void display_error_info(uint8_t status, uint8_t enable_unexpected_error)
{
    switch(status)
    {
        case MSS_SYS_NRBG_CATASTROPHIC_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[0]);
            break;
            
        case MSS_SYS_NRBG_MAX_INST_EXCEEDED:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[1]);
            break;
            
        case MSS_SYS_NRBG_INVALID_HANDLE:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[2]);
            break;
            
        case MSS_SYS_NRBG_GEN_REQ_TOO_BIG:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[3]);
            break;
            
        case MSS_SYS_NRBG_MAX_LENGTH_EXCEEDED:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[4]);
            break;
            
        case MSS_SYS_MEM_ACCESS_ERROR:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[5]);
            break;
            
        case MSS_SYS_SERVICE_NOT_LICENSED:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[6]);
            break;
            
        case MSS_SYS_SERVICE_DISABLED_BY_FACTORY:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[7]);
            break;
            
        case MSS_SYS_SERVICE_DISABLED_BY_USER:
            MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[8]);
            break;
            
        default:
            if((enable_unexpected_error == 1) && (status == MSS_SYS_UNEXPECTED_ERROR))
            {
                MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[9]);
            }
            else
            {
                MSS_UART_polled_tx_string(gp_my_uart, g_errror_message[10]);
            }
            break;
    }
}

/*==============================================================================
  Read the DRBG handler number from UART terminal.
 */
static uint8_t select_drbg_handle(void)
{
    size_t size;
    uint8_t buff[1];
    
    MSS_UART_polled_tx_string(gp_my_uart,
                             (const uint8_t*)" Enter the handler number(0,1,2):");
    for(;;)
    {
        /* Start command line interface if any key is pressed. */
        size = MSS_UART_get_rx(gp_my_uart, buff, sizeof(buff));
        if(size > 0)
        {
            MSS_UART_polled_tx(gp_my_uart, buff, sizeof(buff));
            if(buff[0] < '3')
            {
                return(buff[0] - 0x30);
            }
            else
            {
                MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\r\n Error - Invalid handler number. ");
                MSS_UART_polled_tx_string(gp_my_uart,
                                         (const uint8_t*)"\r\n Enter the valid handler number(0,1,2):");
            }
        }
    }
}

