/*******************************************************************************
 * (c) Copyright 2012-2016 Microsemi SoC Products Group.  All rights reserved.
 *
 * This example project demonstrates the use of the SmartFusion2 In Application
 * Programming (IAP) using USB driver.
 *
 * This example uses the USB driver in USB Device mode with MSC class. When
 * SmartFusion2 is connected to host PC through USB micro-AB connector, it will
 * appear as a removable mass storage drive. You can drag and drop the
 * programming file onto this drive which will then be used to program SmartFusion2.
 * The programming file must be stored on the root directory of this drive.
 * Multiple programming files can be copied on the drive.
 *
 * For more information on how to use this project, please refer README.TXT in
 * this project's folder.
 *
 * SVN $Revision: 8346 $
 * SVN $Date: 2016-03-23 12:18:12 +0530 (Wed, 23 Mar 2016) $
 */
#include "drivers/mss_sys_services/mss_sys_services.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_spi/mss_spi.h"

#include "flash_drive_app.h"
#include "FAT/src/ff.h"
#include "FAT/src/diskio.h"
#include "drivers/w25q64fvssig/w25q64fvssig.h"
//#include "./drivers/at25df641/at25df641.h"
/*------------------------------------------------------------------------------
  Macros.
 */
#define PAGE_LENGTH               512
#define SPI_FLASH_COPY_LOCATION   0x400000u

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_option_msg[] =
" Enter desired action to perform in the below mentioned sequence: \r\n\
   1. Display list of .spi files available on root directory \r\n\
   2. Select the file name for programming \r\n\
   3. Authenticate device \r\n\
   4. Program device \r\n\
   5. Verify device \r\n\
   6. Help \r\n\
 Enter valid selection [1-6]: \r\n";

const uint8_t g_separator[] = 
"\r\n----------------------------------------------------------------------\r\n";

/*------------------------------------------------------------------------------
  Private functions.
 */
static void display_greeting(void);
static void Init_FS(void);
FRESULT scan_files(char* path);
static void get_file_name(void);
static uint32_t msd_read
(
    uint8_t * g_page_buffer,
    uint32_t length
);
static void spi_flash_write
(
    uint32_t address,
    uint8_t *tx_buffer,
    size_t size_in_bytes
);
static void wait_ready(void);
static void init_UART(void);
static void display_options(void);

/*------------------------------------------------------------------------------
  Global variables.
 */
static uint32_t file_opened = 0u;
static uint8_t read_buffer[PAGE_LENGTH];
FATFS fs[1];
FIL fdst;
uint8_t res;
uint32_t g_bytes_read;
uint8_t file_spi[50];

/*------------------------------------------------------------------------------
  UART selection.
  Replace the line below with this one if you want to use UART1 instead of
  UART0:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*------------------------------------------------------------------------------
  Main function.
 */
int main()
{
    uint8_t status;
    size_t rx_size;
    uint8_t rx_buff[1];
    uint32_t byte_Read = 0;
    uint32_t remaining_size = 0;
    uint32_t write_address = SPI_FLASH_COPY_LOCATION;
    uint32_t bitstream_spi_addr = SPI_FLASH_COPY_LOCATION;
    int8_t tx_complete;
    
    MSS_SYS_init(MSS_SYS_NO_EVENT_HANDLER);
    
    init_UART();

    FLASH_DRIVE_init();
    
    Init_FS();
    
    /* Display greeting message. */
    display_greeting();
    
    /* Display options. */
    MSS_UART_polled_tx (gp_my_uart, g_option_msg,sizeof(g_option_msg));;
    
    for(;;)
    {
        /* Start command line interface if any key is pressed. */
        rx_size = MSS_UART_get_rx(gp_my_uart, rx_buff, sizeof(rx_buff));
        if(rx_size > 0)
        {
            switch(rx_buff[0])
            {
                /* Scan SF2 - mass storage device and display the list of file present in it. */
                case '1':
                    scan_files("/..");
                    display_options();
                break;

                case '2':
                    /* Read the file name from UART terminal. */
                    get_file_name();
                    if(!file_opened)
                   {
                        res = f_open(&fdst, (char const *)file_spi, FA_OPEN_EXISTING | FA_READ);
                        if(res)
                        {
                            file_opened = 0u;
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n Can not open the requested file.");
                        }
                        else
                        {
                            disable_usb();
                            file_opened = 1u;
                            write_address = SPI_FLASH_COPY_LOCATION;
                            bitstream_spi_addr = SPI_FLASH_COPY_LOCATION;
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\n File Opened.");
                        }
                    }
                    if(file_opened == 1u)
                    {
                        remaining_size = fdst.fsize;
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Copying the selected file from mass storage device into SPI FLASH.\r\n Please wait..");

                        while(remaining_size != 0)
                        {
                            /* 
                             * Read the file from the mass storage device and copy the 
                             * file in SPI flash from location 0x400000h onwards. 
                             */
                            byte_Read = msd_read(read_buffer, sizeof(read_buffer));
                            if(remaining_size >= byte_Read)
                            {
                                remaining_size = remaining_size - byte_Read;
                                if(byte_Read == 0)
                                {
                                    break;
                                }
                            }
                            else
                            {
                                remaining_size = 0x00u;
                            }
                            
                            /* Erase 4k block. */
                            if((write_address % 0x1000) == 0)
                            {
                                FLASH_erase_4k_block(write_address);
                            }

                            spi_flash_write(write_address, read_buffer, byte_Read);
                            write_address +=byte_Read;
                            wait_ready();
                        }
                        file_opened = 0u;
                        if(remaining_size == 0)
                        {
                            /* Close the file. */
                            f_close(&fdst);
                            MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n SPI Flash Programming completed.");
                        }
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    display_options();
                break;
                
                case '3':
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Selected - Authentication service.\r\n IAP - Authentication service will take 4-5 min to complete.\r\n Please wait..");
                    do {
                        tx_complete = MSS_UART_tx_complete(gp_my_uart);
                    } while(0 == tx_complete);

                    MSS_SPI_set_slave_select( &g_mss_spi0, MSS_SPI_SLAVE_0 ); // Slave SELECT signal asserted
                    g_mss_spi0.hw_reg->CONTROL |= (0x04000000);

                    status = MSS_SYS_initiate_iap(MSS_SYS_PROG_AUTHENTICATE, bitstream_spi_addr);
                    MSS_SPI_clear_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0);

                    init_UART();
                    
                    if(MSS_SYS_SUCCESS == status)
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Authentication successful.");
                    }
                    else
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Authentication failed.");
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    display_options();
                break;
                
                case '4':
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Selected - IAP Programming service.\r\n IAP - Programming service will take 4-5 min to complete.\r\n Please wait..");
                    do {
                        tx_complete = MSS_UART_tx_complete(gp_my_uart);
                    } while(0 == tx_complete);

                    MSS_SPI_set_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0); // Slave SELECT signal asserted
                    g_mss_spi0.hw_reg->CONTROL |= (0x04000000);
                    
                    status = MSS_SYS_initiate_iap(MSS_SYS_PROG_PROGRAM, bitstream_spi_addr);
                    MSS_SPI_clear_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0);

                    init_UART();

                    if(MSS_SYS_SUCCESS == status)
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Programming successful.");
                    }
                    else
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Programming failed.");
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    display_options();
                break;
                
                case '5':
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Selected - Verification service.\r\n IAP - Verification service will take 4-5 min to complete.\r\n Please wait..");
                    do {
                        tx_complete = MSS_UART_tx_complete(gp_my_uart);
                    } while(0 == tx_complete);
                    MSS_SPI_set_slave_select( &g_mss_spi0, MSS_SPI_SLAVE_0 ); // Slave SELECT signal asserted
                    g_mss_spi0.hw_reg->CONTROL |= (0x04000000);
                    
                    status = MSS_SYS_initiate_iap(MSS_SYS_PROG_VERIFY, bitstream_spi_addr);
                    MSS_SPI_clear_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0);
                    
                    init_UART();
                    
                    if(MSS_SYS_SUCCESS == status)
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Verification successful.");
                    }
                    else
                    {
                        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t*)"\r\n Verification failed.");
                    }
                    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
                    display_options();
                break;
                
                case '6':
                    display_greeting();
                    display_options();
                break;
                
                default:
                    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" Error: Invalid action.");
                    display_options();;
                break;
            }
        }
    }
}

/*------------------------------------------------------------------------------
  Display user option to execute IAP service.
 */
static void display_options(void)
{
    uint8_t rx_size = 0;
    uint8_t rx_data = 0;

    MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\r\nPress any key to continue...");
    do {
        rx_size = MSS_UART_get_rx(gp_my_uart, &rx_data,1);
    } while(rx_size == 0);

    MSS_UART_polled_tx_string(gp_my_uart, g_separator);
    MSS_UART_polled_tx (gp_my_uart, g_option_msg,sizeof(g_option_msg));
    return;
}

/*------------------------------------------------------------------------------
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"\n\r\n\r**********************************************************************\n\r" );
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"********** SmartFusion2 In Application Programming Example ***********\n\r" );
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"**********************************************************************\n\r" );
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)" This Example project will provide following options to user:  \n\r");
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)" 1. To store the bit stream (.spi file) on to SPI-Flash using USB-Mass\n\r");
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"    Storage Device Driver.\n\r");
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)" 2. Select bit stream file for programming from the Root directory of \n\r");
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"    the drive and display for user to select .spi file\n\r" );
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)" 3. Performs Programming activity. \n\r" );
    MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)"----------------------------------------------------------------------\n\r" );
}
/*------------------------------------------------------------------------------
  Initializing UART.
 */
static void init_UART(void)
{
    MSS_UART_init(gp_my_uart,
                  MSS_UART_115200_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
}

/*------------------------------------------------------------------------------
 Initializing the file system on SPI-FLASH.
*/
static void Init_FS()
{
    long p2;
    FATFS *fatfs;

    /* File System  on SPI Flash Init */
    if (disk_initialize(0))
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" Disk Initialization Failed: SPI interface Error: \n\r");
    }
    else
    {
        f_mount(0, &fs[0]);

        if(f_getfree("0:", (DWORD*)&p2, &fatfs))
        {
            /* Create the File System */
            if (f_mkfs(0, 0, 512))
            {
                MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)" File System Cannot be created: \n\r");
            }
        }
    }
}

/*------------------------------------------------------------------------------
  Scan for .spi files in the root directory and display on hyper-terminal.
 */
FRESULT scan_files(char* path)
{
    FRESULT res;
    FILINFO fno;
    DIR dir;
    uint8_t flag=0;
    int k;

    res = f_opendir(&dir, path);
    if (res == FR_OK)
    {
        MSS_UART_polled_tx_string(gp_my_uart, (const uint8_t *)"\n\r List of .SPI files in Root Directory: ");
        for (;;)
        {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            if (fno.fname[0] == '.') continue;             /* Ignore dot entry */
            
            if (fno.fattrib & AM_DIR)
            {
                /* It is a directory */
            }
            else
            {
                /* It is a file. */
                k = 0;
                /* Is this file of type .spi*/
                while(fno.fname[k] != '\0')
                {
                    if(fno.fname[k] == '.')
                    {
                        if(((fno.fname[k+1] == 'S') | (fno.fname[k+1] == 's')) \
                          &((fno.fname[k+2] == 'P') | (fno.fname[k+2] == 'p')) \
                          &((fno.fname[k+3] == 'I') | (fno.fname[k+3] == 'i')) \
                          &(fno.fname[k+4] == '\0'))
                       {
                           flag = 1;
                           break;
                       }
                  }
                  else
                  {
                  }
                  k++;
                }
                k = 0;
                if(flag == 1)
                /* Display .spi files */
                {
                    flag = 0;
                    MSS_UART_polled_tx_string( gp_my_uart, (const uint8_t *)"\n\r File Name: \t");
                    while(fno.fname[k] != '\0')
                    {
                        MSS_UART_polled_tx (gp_my_uart, (uint8_t const *)&fno.fname[k], 1);
                        k++;
                    }
                }
            }
        }
        MSS_UART_polled_tx_string(gp_my_uart, g_separator);
    }
    return res;
}

/*------------------------------------------------------------------------------
  Get the file name to read from SPI-FLASH
 */
static void get_file_name(void)
{
    uint8_t tx_data[] = {"\r\n Enter the file name to read bit stream from SPI memory device: "};
    uint8_t rx_data = 0;
    uint8_t rx_size = 0;
    uint8_t index = 0;
    uint8_t done = 0;

    MSS_UART_polled_tx (gp_my_uart, tx_data,sizeof(tx_data));

    index = 0;
    while (!done)
    {
        do {
            rx_size = MSS_UART_get_rx(gp_my_uart, &rx_data, 1);
        } while(rx_size == 0);
        if ((rx_data == '\r') || (rx_data == '\n'))
        {
            done = 1;
        }
        else if (rx_data == 8)
        {
            index--;
        }
        else
        {
            file_spi[index]=rx_data;
            MSS_UART_polled_tx (gp_my_uart, &file_spi[index], 1);
            index++;
        }
    }
    file_spi[index] = '\0';
}

/*------------------------------------------------------------------------------
  Read the file from the mass storage device.
 */
static uint32_t msd_read
(
    uint8_t * g_page_buffer,
    uint32_t length
)
{
    static uint8_t l_counter = 0;

    if(file_opened)
    {
        res = f_read(&fdst, g_page_buffer, PAGE_LENGTH,(UINT *)&g_bytes_read);
        if((res || g_bytes_read) == 0)
        {

        }
        else
        {
            if(l_counter == 30)
            {
                MSS_UART_polled_tx_string(gp_my_uart,(const uint8_t*)".");
                l_counter = 0;
            }
            else
            {
                l_counter++;
            }
        }
    }
    return g_bytes_read;
}

/*------------------------------------------------------------------------------
  Read the status of SPI flash and wait till SPI FLash becomes ready.
 */
static void wait_ready(void)
{
    uint8_t ready_bit;
    uint8_t command = 0x05;
    
    MSS_SPI_set_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0);
    do {
        MSS_SPI_transfer_block(&g_mss_spi0, &command, sizeof(command), &ready_bit, sizeof(ready_bit));
        ready_bit = ready_bit & 0x01;
    } while(ready_bit == 1);
    MSS_SPI_clear_slave_select(&g_mss_spi0, MSS_SPI_SLAVE_0);
}

/*------------------------------------------------------------------------------
  Write the data in to SPI Flash.
 */
static void spi_flash_write
(
    uint32_t address,
    uint8_t *tx_buffer,
    size_t size_in_bytes
)
{
    FLASH_program(address, tx_buffer, size_in_bytes);
}
