/*******************************************************************************
 * (c) Copyright 2015 Microsemi SoC Products Group.  All rights reserved.
 * 
 * This example project demonstrates the use of the SmartFusion2 watchdog
 * interrupt.
 *
 * Please refer to the file README.txt for further details about this example.
 *
 * SVN $Revision: 7904 $
 * SVN $Date: 2015-09-30 17:29:06 +0530 (Wed, 30 Sep 2015) $
 */
#include <stdio.h>
#include "drivers/mss_watchdog/mss_watchdog.h"
#include "drivers/mss_uart/mss_uart.h"
#include "CMSIS/system_m2sxxx.h"

/*==============================================================================
  Messages displayed over the UART.
 */
const uint8_t g_greeting_msg[] =
"\r\n\r\n\
**********************************************************************\r\n\
************** SmartFusion2 Watchdog Interrupt Example ***************\r\n\
**********************************************************************\r\n\
 This example project demonstrates the use of the SmartFusion2\r\n\
 watchdog interrupt.\r\n";

const uint8_t g_instructions_msg[] =
"\r\n\
 Press the \"l\" key to force an application lock-up. This will in turn\r\n\
 cause a watchdog interrupt once the watchdog timer expires.\r\n";

const uint8_t  g_lock_cmd_rxed_msg[] =
"\r\n\
----------------------------------------------------------------------\r\n\
 Lock up command received. Waiting for watchdog down counter to\r\n\
 expire.\r\n\r\n";


const uint8_t g_wd_irq_msg[] =
"\r\n\r\n\
----------------------------------------------------------------------\r\n\
!!!!!!!!!!!!!!!!!!!!!!!!! Watchdog Interrupt !!!!!!!!!!!!!!!!!!!!!!!!!\r\n\
----------------------------------------------------------------------\r\n";

/*==============================================================================
  Defines.
 */
#define WDOG_SYSREG_CR_ENABLE_MASK      0x00000001u
#define WDOG_SYSREG_CR_MODE_MASK        0x00000002u

/*==============================================================================
  Private functions.
 */
static void display_greeting(void);
static void display_wd_value(void);
static void delay(void);

/*==============================================================================
  UART selection.
  Replace the line below with this one if you want to use UART0 instead of
  UART1:
  mss_uart_instance_t * const gp_my_uart = &g_mss_uart1;
 */
mss_uart_instance_t * const gp_my_uart = &g_mss_uart0;

/*==============================================================================
  Global variables.
 */
volatile uint32_t g_lockup = 0u;

/*==============================================================================
  Main function.
 */
int main()
{
    uint8_t rx_size = 0;
    uint8_t rx_key;
    
    uint32_t refresh_allowed;

    /*
     * System register configuration that should be done through Libero to
     * enable the watchdog into interrupt mode:
     */
    SYSREG->WDOG_CR = (WDOG_SYSREG_CR_ENABLE_MASK | WDOG_SYSREG_CR_MODE_MASK);
    
    /* Watchdog initialization. */
    MSS_WD_init();
    
    /* Enable watchdog timeout interrupt. */
    MSS_WD_enable_timeout_irq();
    MSS_WD_enable_wakeup_irq();
    
    /* MMUART initialization */
    MSS_UART_init(gp_my_uart,
                  MSS_UART_57600_BAUD,
                  MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT);
                  
    /* Display greeting message. */
    display_greeting();
  
    g_lockup = 0u;
    
    /*
     * Foreground loop.
     */
    for(;;)
    {
        /*
         * Refresh watchdog.
         */
        refresh_allowed = MSS_WD_status();
        if(refresh_allowed)
        {
            MSS_WD_reload();
        }
         
        /*
         * Check received UART characters for command to lock up application
         * code.
         */
        rx_size = MSS_UART_get_rx(gp_my_uart, &rx_key, sizeof(rx_key));
        if(rx_size > 0)
        {
            if(('l' == rx_key) || ('L' == rx_key))
            {
                g_lockup = 1u;
                MSS_UART_polled_tx_string(gp_my_uart, g_lock_cmd_rxed_msg);
            }
        }
        
        /*
         * Lock up application code if requested by user.
         */
        while(1u == g_lockup)
        {
            /*
             * Wait for watchdog to generate interrupt.
             */
            display_wd_value();
            delay();
        }
    }
    
}

/*==============================================================================
  Watchdog time out interrupt service routine
 */
void NMI_Handler(void)
{
    g_lockup = 0u;
    
    MSS_WD_clear_timeout_irq();
    
    MSS_UART_polled_tx_string(gp_my_uart, g_wd_irq_msg);
    MSS_UART_polled_tx_string(gp_my_uart, g_instructions_msg);
}

/*==============================================================================
  Display greeting message when application is started.
 */
static void display_greeting(void)
{
    MSS_UART_polled_tx_string(gp_my_uart, g_greeting_msg);
    MSS_UART_polled_tx_string(gp_my_uart, g_instructions_msg);
}

/*==============================================================================
  Display current watchdog down counter value.
 */
static void display_wd_value(void)
{
    uint32_t wd_value;
    uint8_t display_buffer[128];
    
    wd_value = MSS_WD_current_value();
    if(wd_value > 0x00080000u)
    {
        snprintf((char* )display_buffer,
                 sizeof(display_buffer),
                 " Watchdog down counter value: 0x%08x  \r",
                 (unsigned int)wd_value);
                 
        MSS_UART_polled_tx_string(gp_my_uart, display_buffer);
    }
}

/*==============================================================================
  Delay between displays of the watchdog counter value.
 */
static void delay(void)
{
    volatile uint32_t delay_count = SystemCoreClock / 128u;
    
    while(delay_count > 0u)
    {
        --delay_count;
    }
}

